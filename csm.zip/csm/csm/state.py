from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional
from pathlib import Path
import pickle as pkl

import pandas as pd

from functools import wraps

from .data import download_data
from .universe import Universe, NasdaqUniverse
from .signals import PortfolioBuilder, CsmPortfolioBuilder
from .util import (
    equity
    , return_
    , drawdown
)

TICKERS_CACHE_PATH: Path = Path('./.cache/ticker.pkl')

def cached_on_state(attr: str):
    def decorator(fn):
        @wraps(fn)
        def wrapper(cfg, state: State, **kwargs):
            if getattr(state, attr, None) is None:
                setattr(state, attr, fn(cfg=cfg, state=state, **kwargs))
            return getattr(state, attr)
        return wrapper
    return decorator

#####################################################################################
##################### Identifying Universe and Downloading Data #####################
#####################################################################################
@cached_on_state('tickers')
def get_tickers(cfg, state):
    universe_name = getattr(cfg, 'universe_name', 'NASDAQ')

    universe: Universe = None
    match universe_name:
        case 'NASDAQ': universe = NasdaqUniverse
        case _: raise RuntimeError(f'Unkown Universe: {universe_name}')

    use_cached_tickers = getattr(cfg, 'use_cached_tickers', True)

    if use_cached_tickers and TICKERS_CACHE_PATH.exists():
        with open(TICKERS_CACHE_PATH, 'rb') as f:
            return pkl.load(f)
    else:
        tickers = universe.load(cfg)
        with open(TICKERS_CACHE_PATH, 'wb') as f:
            pkl.dump(state.tickers, f)
        return tickers

################################
########## Price Data ##########
################################
@cached_on_state('data')
def get_data(cfg, state):
    t = get_tickers(cfg, state)
    return download_data(cfg, t)

@cached_on_state('price_spy')
def get_spy_price(cfg, state, **kwargs):
    return download_data(cfg, ['SPY']).Close.iloc[:, 0]

@cached_on_state('price_tbill')
def get_t_bill_price(cfg, state):
    return download_data(cfg, ['BIL']).Close.iloc[:, 0] / 100

@cached_on_state('price_global_market')
def get_global_market_price(cfg, state, **kwargs):
    t = getattr(cfg, 'global_market_etf_ticker')
    return download_data(cfg, [t]).Close.iloc[:, 0]

#######################################
########## Price Return Data ##########
#######################################
@cached_on_state('return_tbill')
def get_tbill_returns(cfg, state, **kwargs):
    tbill = get_t_bill_price(cfg, state)
    return tbill.pct_change()

@cached_on_state('return_tickers')
def get_tickers_returns(cfg, state, **kwargs):
    return return_(get_data(cfg, state))

@cached_on_state('return_spy')
def get_spy_returns(cfg, state):
    return return_(get_spy_price(cfg, state))

@cached_on_state('portfolio_returns')
def get_portfolio_returns(cfg, state, **kwargs):
    signal = get_signal_df(cfg=cfg, state=state, **kwargs)
    ret = get_tickers_returns(cfg=cfg, state=state, **kwargs)
    return (ret * signal).sum(axis=1, min_count=1)

#######################################
##########       Equity      ##########
#######################################
@cached_on_state('portfolio_equity_curve')
def get_portfolio_equity(cfg, state, **kwargs):
    ret = get_portfolio_returns(cfg, state)
    return equity(ret)

@cached_on_state('benchmark_equity_curve')
def get_spy_equity(cfg, state, **kwargs):
    ret = get_spy_returns(cfg, state)
    return equity(ret)

#####################################################################################
#####################           Portfolio Building              #####################
#####################################################################################
@cached_on_state('signal_df')
def get_signal_df(cfg, state, **kwargs):
    pb_name = getattr(cfg, 'strategy', 'Global Equity Market')
    portfolio_builder: PortfolioBuilder = None
    match pb_name:
        case 'Global Equity Market': portfolio_builder = CsmPortfolioBuilder
        case _: raise RuntimeError(f'Unkown Strategy: {pb_name}')
    return portfolio_builder.build_signal(cfg, state)


#####################################################################################
#####################           Portfolio Functions             #####################
#####################################################################################
@cached_on_state('portfolio_drawdown')
def get_portfolio_drawdown(cfg, state: State, **kwargs) -> pd.Series:
    eqty = get_portfolio_equity(cfg, state)
    return drawdown(eqty)

@cached_on_state('benchmark_drawdown')
def get_spy_drawdown(cfg, state, **kwargs):
    eqty = get_spy_equity(cfg, state)
    return drawdown(eqty)

@dataclass
class State:
    """Empty/None at the start, filled in as the pipeline runs."""
