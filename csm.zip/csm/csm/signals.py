from __future__ import annotations

import logging
from abc import ABC, abstractmethod

import numpy as np
import pandas as pd
from tqdm import tqdm
from scipy.stats import zscore

from .config import Config
from .state import (
    State
    , get_t_bill_price, get_spy_price, get_global_market_price
    , get_tickers_returns
)
from .util import (
    yearly_return
    , absolute_momentum
)

logger = logging.getLogger(__name__)

class PortfolioBuilder(ABC):
    @staticmethod
    @abstractmethod
    def build_signal(cfg: Config, state) -> pd.DataFrame: ...

    @staticmethod
    def _make_signal_df(cfg: Config, state: State):
        trade_freq = getattr(cfg, 'trade_freq', 'W-MON')
        return pd.DataFrame(0.0, columns=state.data.Close.columns, index=state.data.index)

class Signal(ABC):
    @staticmethod
    @abstractmethod
    def signal(cfg: Config, state: State) -> None | pd.DataFrame: ...

##########################################################################
#####################     My Portfolio Builder       #####################
##########################################################################
class CsmPortfolioBuilder(PortfolioBuilder):
    @staticmethod
    def build_signal(cfg: Config, state: State) -> pd.DataFrame:
        signal_df = PortfolioBuilder._make_signal_df(cfg, state)

        dm_df = DualMomInd.signal(cfg, state)
        iv_df = InvVolSig.signal(cfg, state)
        fip_df = FrogInPan.signal(cfg, state)
        ret_us_eqty_s = UsEquityReturns.signal(cfg, state)
        ret_glbl_eqty_s = GlobalEquityReturns.signal(cfg, state)
        ret_tbill_eqty_s = TbillEquityReturns.signal(cfg, state)

        winner_us = ret_us_eqty_s > ret_tbill_eqty_s
        signal_df['tbill'] = np.where(~winner_us, 1.0, 0.0)

        winner_glbl = winner_us & (ret_glbl_eqty_s > ret_us_eqty_s)
        signal_df['glbl'] = np.where(winner_glbl, 1.0, 0.0)


        n_basket = getattr(cfg, 'n_basket', 100)
        for d in tqdm(signal_df.index):
            if winner_glbl.loc[d] or not winner_us.loc[d]: continue

            winner_df = dm_df.loc[d][lambda x: x.gt(0)].to_frame('dm')
            if winner_df.empty: continue

            winner_df['fip'] = fip_df.loc[d, winner_df.index]
            winner_df = winner_df.dropna()
            if winner_df.empty: continue

            winner_df = winner_df.apply(zscore)
            winner_df['score'] = winner_df.sum(axis=1)
            winners = winner_df.nlargest(n_basket, 'score').index

            weight = iv_df.loc[d, winners] / iv_df.loc[d, winners].sum()
            signal_df.loc[d, winners] = weight
        return signal_df

##########################################################################
##################### Global Equity Momentum Signals #####################
##########################################################################
class TbillEquityReturns(Signal):
    @staticmethod
    def signal(cfg, state):
        tbill = get_t_bill_price(cfg, state)
        return yearly_return(tbill)

class UsEquityReturns(Signal):
    @staticmethod
    def signal(cfg, state):
        spy = get_spy_price(cfg, state)
        return yearly_return(cfg, spy)

class GlobalEquityReturns(Signal):
    @staticmethod
    def signal(cfg, state):
        gm = get_global_market_price(cfg, state)
        return yearly_return(cfg, gm)

##########################################################################
#####################      Dual Momentum Signals     #####################
##########################################################################
class DualMomInd(Signal):
    @staticmethod
    def signal(cfg, state) -> pd.DataFrame:
        abs_mom = AbsMomInd.signal(cfg, state)
        rel_mom = RelMomInd.signal(cfg, state)
        return rel_mom * abs_mom.gt(0).astype(float)

# TODO relative to their category not benchmark
class RelMomInd(Signal):
    @staticmethod
    def signal(cfg, state) -> pd.DataFrame:
        spy_mom = absolute_momentum(cfg, get_spy_price(cfg, state))
        return AbsMomInd.signal(cfg, state).sub(spy_mom, axis=0)

class AbsMomInd(Signal):
    @staticmethod
    def signal(cfg, state) -> pd.DataFrame:
        tbill_mom = absolute_momentum(cfg, get_t_bill_price(cfg, state))
        return absolute_momentum(cfg, state.data.Close).sub(tbill_mom, axis=0)

# # this sucks
# class SpySmaMrf(Signal):
#     @staticmethod
#     def signal(cfg, state):
#         lb = getattr(cfg, 'spy_sma_lb', 252)
#         return state.benchmark <= state.benchmark.rolling(lb).mean()

##########################################################################
#####################    Momentum Related Signals    #####################
##########################################################################
class InvVolSig(Signal):
    @staticmethod
    def signal(cfg, state):
        lb = getattr(cfg, 'inverse_volatility_lookback', 21)
        ret = get_tickers_returns(cfg, state)
        vol = ret.rolling(lb).std().shift(1)
        return 1 / vol.replace(0, np.nan)

class FrogInPan(Signal):
    @staticmethod
    def signal(cfg, state):
        ret = get_tickers_returns(cfg, state)
        lb = getattr(cfg, "frog_in_pan_lb", 21)
        pos = ret.gt(0).rolling(lb).mean()
        neg = ret.lt(0).rolling(lb).mean()
        cum_ret = ret.rolling(lb).apply(
            lambda x: np.prod(1 + x) - 1,
            raw=True,
        )
        return -np.sign(cum_ret) * (neg - pos)

