from __future__ import annotations

import datetime as dt
import logging

import pandas as pd
import yfinance as yf

from .config import Config

logger = logging.getLogger(__name__)


def download_data(cfg: Config, tickers: list[str]) -> pd.DataFrame:
    logger.info("Downloading price data for %d tickers (lookback=%d days)", len(tickers), cfg.master_lookback)
    period = dict(
        start=dt.datetime.today() - dt.timedelta(cfg.master_lookback)
        , end=dt.datetime.today()
    )
    data = yf.download(tickers, **period, auto_adjust=True)
    if data.empty:
        raise RuntimeError("No data downloaded.")
    logger.info("Downloaded data: shape=%s", data.shape)
    return data
