from __future__ import annotations

import logging
from abc import ABC, abstractmethod
from io import StringIO

import pandas as pd
import requests

from .config import Config

logger = logging.getLogger(__name__)


class Universe(ABC):
    @staticmethod
    @abstractmethod
    def load(cfg: Config) -> list[str]: ...


class SP500WikipediaUniverse(Universe):
    @staticmethod
    def load(cfg: Config) -> list[str]:
        logger.info("Loading S&P 500 universe from %s", cfg.wiki_url)
        resp = requests.get(cfg.wiki_url, headers=cfg.headers, timeout=15)
        tables = pd.read_html(StringIO(resp.text))
        df = tables[cfg.table_index]
        tickers = df[cfg.ticker_col].astype(str).str.strip().tolist()
        tickers = [t.replace(".", "-") for t in tickers]
        tickers = sorted(set(tickers))
        logger.info("Loaded %d tickers", len(tickers))
        return tickers
