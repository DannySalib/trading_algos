from __future__ import annotations 

import pandas as pd 

from .forecast import Forecast
from ...models.signal import Signal
from ...config import CACHE_PATH
from ...cache_functions import is_stale, cache_get, cache_put

AVG_ABS_MIN_PERIOD = 10
_CACHE_PATH_FORECASTS = CACHE_PATH / "forecasts"
_CACHE_TTL = 60 * 60 * 24 * 30 * AVG_ABS_MIN_PERIOD

def construct_forecasts(signals: list[Signal]) -> list[Forecast]:
    try:
        return [Forecast(s) for s in signals]
    except (AttributeError, TypeError, ValueError) as e:
        raise RuntimeError("Failed to initialize forecasts") from e

def stale_forecast_scalar(forecasts: list[Forecast]):
    return is_stale(
        key=_cache_key(forecasts),
        cache_path=str(_CACHE_PATH_FORECASTS),
        ttl=_CACHE_TTL
    )

def apply_forecast_scalar(
    df: pd.DataFrame,
    forecasts: list[Forecast],
    stale_scalar: bool,
) -> pd.DataFrame:
    key = _cache_key(forecasts)
    path = str(_CACHE_PATH_FORECASTS)

    if stale_scalar:
        # df includes the extra AVG_ABS_MIN_PERIOD warmup rows (see padded_period),
        # so the scalar is aligned with df already
        scalar = _compute_scalar(df)
        cache_put(key, scalar, path)
    else:
        cached = cache_get(key, path)
        # value at ts = last cached scalar at or before ts. No lookahead,
        # since every cached value was already lagged when it was computed
        scalar = (
            cached
            .reindex(columns=df.columns)
            .reindex(df.index, method="ffill")
        )

    return (df * scalar).clip(-20, 20)

# TODO this needs to take into account what forecasts ur using and what tickers youre using as well 
# only forecast names for now 
def _cache_key(forecasts: list[Forecast]) -> str:
    return str(sorted(f.name for f in forecasts))

def _compute_scalar(df: pd.DataFrame) -> pd.DataFrame:
    avg_abs = df.abs().expanding(min_periods=AVG_ABS_MIN_PERIOD).median()
    return 10 / avg_abs.where(avg_abs > 0)

def _from_position(data: pd.DataFrame | pd.Series) -> pd.DataFrame | pd.Series:
    return data.shift(1) # remove lookahead bias in ONE place 
