from __future__ import annotations

from pathlib import Path
import logging
import time

logger = logging.getLogger(__name__)

import pandas as pd
from tqdm import tqdm

from tradingsys.models.data_acquisition import DataAcquisitionPlatform
from tradingsys.models.period import Period

from ._base import DataAcquisitionClient, CACHE_PATH
from .yahoo_finance_data_acquisition import YahooFinanceDataAcquisition
from yfinance.exceptions import YFRateLimitError

_OHLC_CACHE = Path(CACHE_PATH/ "price_data")

def get_data_acquisition_client(platform: DataAcquisitionPlatform) -> DataAcquisitionClient:
    logger.info(f"Fetching client for data acquisition platform: {platform}")
    match platform:
        case DataAcquisitionPlatform.YFINANCE:
            return YahooFinanceDataAcquisition()
        case _:
            raise NotImplementedError(f"Unrecognized Data Acquisition Platform: {platform}")

from collections import defaultdict

def get_data(
    client: DataAcquisitionClient,
    tickers: list[str],
    period: Period,
) -> pd.DataFrame:
    """
    Return price data for an entire universe, using the local cache
    whenever possible and fetching only what's missing, in as few
    batched network calls as possible.
    """
    logger.info(f"Getting data with client {client} over period {period} for {len(tickers)} tickers")

    cached_frames: dict[str, pd.DataFrame] = {}
    to_fetch: list[str] = []
    to_patch: dict[Period, list[str]] = defaultdict(list)

    for ticker in tqdm(tickers, desc="Checking cache"):
        data = _read_cache(_cache_path(ticker))

        if data is None or data.empty:
            to_fetch.append(ticker)
        elif _covers(data, period):
            cached_frames[ticker] = _slice(data, period)
        else:
            cached_frames[ticker] = data
            missing = _missing_period(data, period)
            if missing is not None:
                to_patch[missing].append(ticker)

    if to_fetch:

        _fetch_and_cache(client, to_fetch, period.t0, period.tf, period, cached_frames)

    # Tickers sharing an identical gap (the common case: "just today")
    # are fetched together, so this is typically one call, not one per ticker.
    for missing, group in to_patch.items():
        fresh = client.fetch_price_history(group, missing.t0, missing.tf)
        for ticker in group:
            merged = _merge(cached_frames[ticker], _extract_ticker(fresh, ticker))
            _save_cache(_cache_path(ticker), merged)
            cached_frames[ticker] = _slice(merged, period)

    logger.info("Got the data... concatting...")
    return pd.concat(
        [cached_frames[t] for t in tickers],
        axis=1,
        keys=tickers,  # restores (ticker, field) MultiIndex columns
    )

def _fetch_and_cache(
    client: DataAcquisitionClient,
    tickers: list[str],
    t0,
    tf,
    period: Period,
    cached_frames: dict[str, pd.DataFrame],
) -> None:
    fresh = _chunked_fetch(client, tickers, t0, tf)
    for ticker in tickers:
        data = _extract_ticker(fresh, ticker)
        _save_cache(_cache_path(ticker), data)
        cached_frames[ticker] = _slice(data, period)

def _chunked_fetch(client, tickers: list[str], t0, tf, chunk_size: int = 200) -> pd.DataFrame:
    frames = []
    for i in range(0, len(tickers), chunk_size):
        chunk = tickers[i:i + chunk_size]
        for attempt in range(3):
            try:
                frames.append(client.fetch_price_history(chunk, t0, tf))
                break
            except YFRateLimitError:
                wait = 10 * (attempt + 1)
                logger.warning(f"Rate limited on chunk {i}-{i+chunk_size}, waiting {wait}s")
                time.sleep(wait)
        time.sleep(1)  # small gap between chunks regardless
    return pd.concat(frames, axis=1)

def _save_cache(
    path: Path,
    data: pd.DataFrame,
) -> None:
    if data.empty:
        # Nothing useful to cache (e.g. delisted ticker, no data
        # returned by the platform). Caching it would write a
        # parquet file some engines (fastparquet) can't read back.
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    data.to_parquet(path)

def _read_cache(path: Path) -> pd.DataFrame | None:
    if not path.exists():
        return None
    try:
        return pd.read_parquet(path)
    except Exception:
        logger.warning(f"Cache at {path} is unreadable, refetching")
        path.unlink(missing_ok=True)
        return None

def _extract_ticker(data: pd.DataFrame, ticker: str) -> pd.DataFrame:
    """Pull one ticker's columns back out of a multi-ticker download."""
    if isinstance(data.columns, pd.MultiIndex):
        return data[ticker] if ticker in data.columns.get_level_values(0) else pd.DataFrame()
    return data

def _cache_path(ticker: str) -> Path:
    return _OHLC_CACHE / f"{ticker}.parquet"

def _covers(data: pd.DataFrame, period: Period) -> bool:
    if data.empty:
        return False

    index = _normalize_index(data.index)

    return (
        index.min() <= pd.Timestamp(period.t0)
        and index.max() >= pd.Timestamp(period.tf)
    )

def _missing_period(
    data: pd.DataFrame,
    period: Period,
) -> Period | None:
    index = _normalize_index(data.index)

    start = pd.Timestamp(period.t0)
    end = pd.Timestamp(period.tf)

    cached_start = index.min()
    cached_end = index.max()

    # Requested period is completely contained in cache.
    if cached_start <= start and cached_end >= end:
        return None

    # Missing data before the cached range.
    if start < cached_start:
        return Period(
            t0=start,
            tf=min(end, cached_start),
        )

    # Missing data after the cached range.
    return Period(
        t0=max(start, cached_end),
        tf=end,
    )

def _merge(
    cached: pd.DataFrame,
    new: pd.DataFrame,
) -> pd.DataFrame:
    data = pd.concat([cached, new])

    # Avoid duplicate dates when the acquisition API includes
    # the boundary date from the existing cache.
    data = data[~data.index.duplicated(keep="last")]

    return data.sort_index()

def _slice(
    data: pd.DataFrame,
    period: Period,
) -> pd.DataFrame:
    return data.loc[
        pd.Timestamp(period.t0):pd.Timestamp(period.tf)
    ]

def _normalize_index(index: pd.Index) -> pd.DatetimeIndex:
    index = pd.DatetimeIndex(index)

    if index.tz is not None:
        index = index.tz_localize(None)

    return index.normalize()